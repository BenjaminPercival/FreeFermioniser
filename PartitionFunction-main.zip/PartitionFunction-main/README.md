# PartitionFunction

This is a python script to evaluate the partition function and one-loop cosmological constant for free-fermionic heterotic strip theories.
